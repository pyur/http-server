package ru.pyur.tst;

public class Cookie {


}
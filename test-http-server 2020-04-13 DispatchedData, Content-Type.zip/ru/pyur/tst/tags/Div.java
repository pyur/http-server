package ru.pyur.tst.tags;


public class Div extends Tag {


    public Div() {
        tag_name = "div";
    }


}
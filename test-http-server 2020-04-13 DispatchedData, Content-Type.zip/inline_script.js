
function ajaxMin(url, cbSuccess, cbFailed) {
  var ar = new XMLHttpRequest();

  ar.onreadystatechange = function() {
    if (this.readyState == 4) {
      if (this.status == 200) {
        cbSuccess(this.responseText);
        }
      else {
        if (cbFailed)  cbFailed(this);
        }
      }
    };

  ar.open('GET', url, true);

  ar.send();
  }



function setSpriteActions() {
  //search for already setted sprite, and remove it if necessary
  var fst = document.getElementById('spriteActions');
  if (fst) {
    console.log('found. removing setted sprite...');
    fst.parentNode.removeChild(fst);
    console.log('setting new.');
    }
  var st = document.createElement('STYLE');
  st.id = 'spriteActions';
  st.innerHTML = 'a.s {background-image: url(' + localStorage.spriteActions + ');}';
  document.head.appendChild(st);
  }



if (localStorage.spriteActions) {
  console.log('get sprite from cache.');
  setSpriteActions();
  }
else {
  console.log('sprite miss in cache.');
  }



function spriteActionsLoaded(r) {
  var aw = {};

  try { aw = JSON.parse(r); }
  catch(e) { return; }

  console.log('new sprite loaded and put to cache.');

  localStorage.spriteActions = aw.data;
  localStorage.tsSpriteActions = aw.ts;
  console.log('new sprite ts: ' + aw.ts);

  setSpriteActions();
  }


if (localStorage.tsSpriteActions == undefined || localStorage.tsSpriteActions < tsSpriteActions) {
  console.log('cached sprite is outdated.');
  ajaxMin('/res/sa/', spriteActionsLoaded);
  }
else {
  console.log('cached sprite is actual.');
  console.log('localStorage.tsSpriteActions ('+localStorage.tsSpriteActions+')' + ' > ' + 'tsSpriteActions ('+tsSpriteActions+')');
  }


package ru.pyur.tst.tags;

import java.util.ArrayList;

public class Table extends Tag {

    private boolean hasHeader = false;

    private ArrayList<TableColumn> columns = new ArrayList<>();

    public static final int TABLE_COLUMN_ALIGN_DEFAULT = 0;
    public static final int TABLE_COLUMN_ALIGN_LEFT = 1;
    public static final int TABLE_COLUMN_ALIGN_CENTER = 2;
    public static final int TABLE_COLUMN_ALIGN_RIGHT = 3;

    private class TableColumn {
        public String description;
        public int width;
        public int align;

        public TableColumn(String description, int width, int align) {
            this.description = description;
            this.width = width;
            this.align = align;
        }
    }


    boolean hasActions = false;

    private ArrayList<ActionButton> actions = new ArrayList<>();

    private class ActionButton {
        public String icon;
        public String description;
        //public String location;

        public ActionButton(String icon) {
            this(icon, "");
        }

        public ActionButton(String icon, String description) {
            this.icon = icon;
            this.description = description;
        }
    }



    public Table() {
        tag_name = "table";
    }



    public void addColumn(String description, int width) {
        addColumn(description, width, TABLE_COLUMN_ALIGN_DEFAULT);
    }



    public void addColumn(String description, int width, int align) {
        if (description != null) { hasHeader = true; }

        if (!hasPre) {
            hasPre = true;
            classes.add("lst");
        }

        columns.add(new TableColumn(description, width, align));
    }



    public void addAction(String icon) {
        if (!hasActions) {
            hasActions = true;
        }

        actions.add(new ActionButton("icon"));
    }



    @Override
    public String renderPre() {
        if (actions.size() != 0) {
            String actions_desc = null;
            if (hasHeader) {
                switch(actions.size()) {
                    case 1:
                        actions_desc = "Д";
                        break;
                    case 2:
                        actions_desc = "Д.";
                        break;
                    case 3:
                        actions_desc = "Дейст";
                        break;
                    case 4:
                        actions_desc = "Действ";
                        break;
                    default:
                        actions_desc = "Действия";
                        break;
                }
            }
            addColumn(actions_desc, actions.size() * 18);
        }


        StringBuilder sb = new StringBuilder();

        if (columns.size() != 0) {
            sb.append("\r\n<style>\r\n");

            int i = 1;
            for (TableColumn tc : columns) {
                sb.append("table.lst td:nth-child(");
                //todo: exclude optional head row. tr:nth-child(n+1)
                sb.append(i);
                sb.append(") {");

                sb.append("width: ");
                sb.append(tc.width);
                sb.append("px;");

                if (tc.align == TABLE_COLUMN_ALIGN_LEFT) {
                    sb.append("text-align: left; padding: 0 0 0 2px;");
                } else if (tc.align == TABLE_COLUMN_ALIGN_CENTER) {
                    sb.append("text-align: center; padding: 0;");
                } else if (tc.align == TABLE_COLUMN_ALIGN_RIGHT) {
                    sb.append("text-align: right; padding: 0 2px 0 0;");
                }

                sb.append("}\r\n");
                i++;
            }

            if (actions.size() != 0) {
                //table.lst td:nth-child(7) > a:nth-child(1) {background-position: -288px -64px;}

                int j = 1;
                for (ActionButton but : actions) {
                    sb.append("table.lst td:nth-child(");
                    sb.append(columns.size());
                    sb.append(") > a:nth-child(");
                    sb.append(j);
                    sb.append(")");

                    sb.append(" {background-position: ");
                    sb.append(0);
                    sb.append("px ");
                    sb.append(0);
                    sb.append("px;");

//                    switch (j) {
//                        case 1:
//                            sb.append(" border: 1px solid blue;");
//                            break;
//
//                        case 2:
//                            sb.append(" border: 1px solid magenta;");
//                            break;
//
//                        case 3:
//                            sb.append(" border: 1px solid cyan;");
//                            break;
//                    }

                    sb.append("}\r\n");
                    j++;
                }
            }

            sb.append("</style>\r\n");
        }


//        if (actions.size() != 0) {
//            pre.append("\r\n<style>\r\n");
//            //a.i0 {background-position: -288px -64px;}
//            //<a class="i0 s" href="/elec/ele/?elc=1"></a>
//
//            int i = 0;
//            for (ActionButton but : actions) {
//                pre.append("a.i");
//                pre.append(i);
//
//                pre.append(" {background-position: ");
//                pre.append(0);
//                pre.append("px ");
//                pre.append(0);
//                pre.append("px;");
//
//                pre.append("}\r\n");
//                i++;
//            }
//
//            pre.append("</style>\r\n");
//        }


        return sb.toString();
    }



    @Override
    public String renderNested() {
        if (!hasHeader)  return "";

        StringBuilder sb = new StringBuilder();

        if (columns.size() != 0) {
            Tr head_tr = new Tr();
            for (TableColumn tc : columns) {
                //System.out.println(tc.description);
                head_tr.add(new Td(tc.description));
            }

            sb.append(head_tr.toString());
        }

        return sb.toString();
    }


}